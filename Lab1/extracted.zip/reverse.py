#! /usr/bin/python3

from ctypes import resize
import sys, wave
from bitstring import *

def decompose(data):
    return list(map(lambda x: 1 if x else 0, list(BitArray(bytes=data))))

def reverse(audio_path, n_lsb, password, payload_bits, output_path):
    audio = wave.open(audio_path, 'rb')
    audio_params = audio.getparams()
    n_frames = audio.getnframes()
    sample_width = audio.getsampwidth()
    sample_bits = sample_width * 8
    n_channels = audio.getnchannels()


    if n_channels != 1:
        print('[-] Currently, only wav files with one channel are supported. Try to convert your file.')
        exit()

    if n_lsb > sample_bits:
        print('[-] The sample width must not be smaller than the LSB to use.')
        sys.exit()

    frames = audio.readframes(n_frames)
    audio.close()
    frames = [frames[i:i + sample_width] for i in range(0, len(frames), sample_width)]

    displacement = 0
    frame_id = 1
    idx = 0
    secret_bits = []

    for frame in frames:
        frame_bits = decompose(frame)
        if idx < payload_bits:
            for j in range(n_lsb):
                if displacement < password:
                    displacement += 1
                    continue

                secret_bits += [frame_bits[sample_bits - n_lsb + j]]
                idx += 1
            frame_id += 1
        else:
            break

    final = BitArray(secret_bits).bytes
    new_file = open(output_path, 'wb')
    new_file.write(final)
    new_file.close()

def usage(prog_name):
    print('### LSB steganography reverse tool ###')
    print('Usage: %s <audio_path> <n_lsb> <password> <payload_bits> <output_path>' % prog_name)
    sys.exit()

if __name__ == '__main__':
    if len(sys.argv) < 5:
        usage(sys.argv[0])
    reverse(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), sys.argv[5])